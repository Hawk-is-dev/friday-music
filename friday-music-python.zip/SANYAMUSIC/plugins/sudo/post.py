
from pyrogram import Client, filters
from SANYAMUSIC import app
from config import OWNER_ID, BOT_USERNAME, POST_CHANNEL_ID, COMMAND_PREFIXES
from pyrogram.types import Message

@app.on_message(filters.command(["post"], prefixes=COMMAND_PREFIXES) & filters.user(OWNER_ID))
async def copy_messages(_, message):

    if message.reply_to_message:
      
        destination_group_id = POST_CHANNEL_ID
 

        
        await message.reply_to_message.copy(destination_group_id)
        await message.reply("ᴘᴏsᴛ sᴜᴄᴄᴇssғᴜʟ ᴅᴏɴᴇ ")
